import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class cat3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class cat3 extends cat2
{
    /**
     * Act - do whatever the cat3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
