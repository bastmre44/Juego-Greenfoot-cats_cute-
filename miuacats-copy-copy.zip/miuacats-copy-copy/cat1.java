import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class cat1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class cat1 extends Actor
{
       public void act() 
    {
        moveAndTurn();
        eat();
    }
    public void    
     moveAndTurn()
    {
        move(4);
        if (Greenfoot.isKeyDown("left"))
        {
         turn(-3);
        }
        if (Greenfoot.isKeyDown("right"))
        {
         turn(3);
        }
    }
        public void eat()
        {
        Actor worm;
        worm= getOneObjectAtOffset(0,0,obsta1.class);
        if (worm != null)
        {
            World world;
            world= getWorld();
            world.removeObject(worm);
            
            level1 mundo =(level1)world; 
            counter cont = mundo.getcounter(); 
            cont.addcontar();

        }        
        
    }    
        
    
}
