import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)



public class Jugar extends Actor
{
    
    
    public void act() 
    {
        Menu m=(Menu)getWorld();
        if(Greenfoot.mouseMoved(this)){
            
            m.flecha.posicionar(getX()-120,getY());
            
        }
        if(Greenfoot.mouseClicked(this)){
            m.mundoJuego();
        }
    }    
}
