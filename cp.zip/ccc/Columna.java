import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Vector;
/**

 */
public class Columna extends Actor
{
    float p1[]=new float[2];//vector posicion

    float v1;//velocidad horizontal
    boolean primeraVez;
    float tpt;//tiempo por tick(para calculos)
    boolean estoyVivo;
    boolean clonado;//para que solo se clone una vez
    GreenfootImage imagen;
    boolean lugar;//arriba true -- abajo false
    float tiempoEntreExplosion;//tiempo entre efecto explosion roja
    float contadorTiempoExplosion;
    float dps;//daño por segundo
    public Columna(){
        p1[0]=0;
        p1[1]=0;
        v1=0;
        primeraVez=true;

        estoyVivo=true;

        lugar=true;
        imagen=getImage();
        clonado=false;
        tiempoEntreExplosion=0.07f;
        contadorTiempoExplosion=0;
        dps=70;
    }

    public void act() 
    {
        if(primeraVez){
            ReboteWorld mundo=(ReboteWorld)getWorld();
            mundo.anyadirObjetoColumna(this);

            primeraVez=false;
            v1=-120;
            getImage().scale((int)(getImage().getWidth()*1.5),(int)(getImage().getHeight()*1.5));
            if (lugar){

                p1[0]=mundo.getWidth()+200;
                p1[1]=mundo.getHeight()-100+Greenfoot.getRandomNumber(100);
            }else{
                getImage().mirrorVertically();
                p1[0]=mundo.getWidth()+200;
                p1[1]=100-Greenfoot.getRandomNumber(100);
            }

        }

    }

    public void toDo(float ttt){
        tpt=ttt;
        ReboteWorld mundo=(ReboteWorld)getWorld();
        contadorTiempoExplosion=contadorTiempoExplosion+tpt;
        calcularPosicion();

        //if(estoyVivo)getImage().scale((int)tamanyo,(int)tamanyo);
        if(estoyVivo){
            if(isTouching(Player.class)){
                
                mundo.player.vida=mundo.player.vida-dps*tpt;
            }
            if(contadorTiempoExplosion>tiempoEntreExplosion){
                contadorTiempoExplosion=0;
                if(isTouching(Player.class)){
                    
                    Boom explos=(Boom)mundo.nuevoExplosion();
                    explos.p1[0]=mundo.player.p1[0];
                    explos.p1[1]=mundo.player.p1[1];
                    explos.tamanyo=100;

                    explos.tipoExplosion=3;
                }
            }

            posicionar();

        }
    }

    private void posicionar(){
        setLocation((int)p1[0],getWorld().getHeight()-(int)p1[1]);

    }

    private void calcularPosicion(){
        p1[0]=p1[0]+v1*tpt;

        if(p1[0]<-200){
            eliminar(false);
        }

    }

    void eliminar(boolean animacion){
        if(animacion){
            ReboteWorld w =(ReboteWorld) getWorld();
            estoyVivo=false;
            w.vecColumna.removeElement((Columna)this);

            w.removeObject(this);
        }else{
            ReboteWorld w =(ReboteWorld) getWorld();
            estoyVivo=false;
            w.vecColumna.removeElement((Columna)this);
            //System.out.println("Columna "+w.vecColumna.size());

            w.removeObject(this);
        }
    }

}