import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Vector;

public class Boom extends Actor
{
    float p1[]=new float[2];
    float duracionAnimacion;
    float tamanyo;
    boolean primeraVez;
    float tpt;
    boolean estoyVivo;
    GreenfootImage imagen;
    int tipoExplosion;//0=rojo 1=verde 2=rosa
    public Boom(){
        p1[0]=0;
        p1[1]=0;
        primeraVez=true;
        tamanyo=230;
        estoyVivo=true;
        duracionAnimacion=0.15f;
        imagen=getImage();
        tipoExplosion=0;
    }

    public void act() 
    {
        if(primeraVez){
            ReboteWorld mundo=(ReboteWorld)getWorld();
            mundo.anyadirObjetoExplosion(this);
            setLocation((int)p1[0],mundo.getHeight()- (int)p1[1]);
            primeraVez=false;
            switch (tipoExplosion){
                case 0:
                setImage("explosion4.png");
                break;
                case 1:
                setImage("explosion2.png");
                break;
                case 2:
                setImage("explosion3.png");
                break;
                case 3:
                setImage("explosion5.png");
                break;
                default:
                setImage("explosion.png");
                break;

            }
            setRotation(Greenfoot.getRandomNumber(360));
        }

    }
    public void toDo(float ttt){
        tpt=ttt;
        tamanyo=tamanyo-(tamanyo/duracionAnimacion)*tpt;
        //System.out.println("tpt"+tpt+"  "+tamanyo);
        comprobarTamanyo();
        //if(estoyVivo)getImage().scale((int)tamanyo,(int)tamanyo);
        if(estoyVivo){
            getImage().scale((int)tamanyo,(int)tamanyo);

            

        }
    }

    void comprobarTamanyo(){
        if(tamanyo<=1){
            eliminar(false);

        }
    }

void eliminar(boolean animacion){
        if(animacion){
            ReboteWorld w =(ReboteWorld) getWorld();
            estoyVivo=false;
            w.vecExplosion.removeElement((Boom)this);

            w.removeObject(this);
        }else{
            ReboteWorld w =(ReboteWorld) getWorld();
            estoyVivo=false;
            w.vecExplosion.removeElement((Boom)this);
            //System.out.println("explosion "+w.vecExplosion.size());

            w.removeObject(this);
        }
    }

}
