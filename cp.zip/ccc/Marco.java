import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Vector;


public class Marco extends Actor
{
    float p1[]=new float[2];

    float v1;
    boolean primeraVez;
    float tpt;
    boolean estoyVivo;
    boolean clonado;//para que solo se clone una vez
    GreenfootImage imagen;
    boolean lugar;//arriba true -- abajo false
    public Marco(){
        p1[0]=0;
        p1[1]=0;
        v1=0;
        primeraVez=true;

        estoyVivo=true;

        lugar=true;
        imagen=getImage();
        clonado=false;
    }

    public void act() 
    {
        if(primeraVez){
            ReboteWorld mundo=(ReboteWorld)getWorld();
            mundo.anyadirObjetoMarco(this);

            primeraVez=false;
            v1=-120;
            getImage().scale(400, 40);
            if (lugar){
                getImage().mirrorVertically();
                p1[0]=mundo.getWidth()+200;
                p1[1]=mundo.getHeight()-20;
            }else{
                p1[0]=mundo.getWidth()+200;
                p1[1]=20;
            }

        }

    }

    public void toDo(float ttt){
        tpt=ttt;

        calcularPosicion();
        //if(estoyVivo)getImage().scale((int)tamanyo,(int)tamanyo);
        if(estoyVivo){

            posicionar();

        }
    }

    private void posicionar(){
        setLocation((int)p1[0],getWorld().getHeight()-(int)p1[1]);

    }

    private void calcularPosicion(){
        p1[0]=p1[0]+v1*tpt;
        if (!clonado){
            if(p1[0]<750){
                clonado=true;
                ReboteWorld w =(ReboteWorld) getWorld();
                Marco m=w.nuevoMarco();

                m.lugar=lugar;

            }
        } 
        if(p1[0]<-200){
            eliminar(false);
        }

    }

    void eliminar(boolean animacion){
        if(animacion){
            ReboteWorld w =(ReboteWorld) getWorld();
            estoyVivo=false;
            w.vecMarco.removeElement((Marco)this);

            w.removeObject(this);
        }else{
            ReboteWorld w =(ReboteWorld) getWorld();
            estoyVivo=false;
            w.vecMarco.removeElement((Marco)this);
            //System.out.println("Marco "+w.vecMarco.size());

            w.removeObject(this);
        }
    }

}