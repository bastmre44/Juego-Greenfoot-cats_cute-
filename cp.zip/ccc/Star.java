import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Vector;

public class Star extends Actor
{
    float p1[]=new float[2];
    
    float v1;
    boolean primeraVez;
    float tpt;
    boolean estoyVivo;
    GreenfootImage imagen;
    public Star(){
        p1[0]=0;
        p1[1]=0;
        v1=0;
        primeraVez=true;
        
        estoyVivo=true;
        
        imagen=getImage();
    }
    public void act() 
    {
        if(primeraVez){
            ReboteWorld mundo=(ReboteWorld)getWorld();
            mundo.anyadirObjetoEstrella(this);
            p1[0]=mundo.getWidth()+100;
            p1[1]=mundo.getHeight()-Greenfoot.getRandomNumber(mundo.getHeight());
            primeraVez=false;
            v1=-160;
            getImage().setTransparency(220-Greenfoot.getRandomNumber(70));
        }
        
        
    }
    public void toDo(float ttt){
        tpt=ttt;
      
        
        calcularPosicion();
        //if(estoyVivo)getImage().scale((int)tamanyo,(int)tamanyo);
        if(estoyVivo){
            
            posicionar();
        
        }
    }
    private void posicionar(){
        setLocation((int)p1[0],getWorld().getHeight()-(int)p1[1]);
        
    }
    private void calcularPosicion(){
        p1[0]=p1[0]+v1*tpt;
        
        if(p1[0]<0-50){
            eliminar(false);
        }else if(p1[1]<0-50){
            eliminar(false);
        }
        if(estoyVivo){
            if(p1[0]>getWorld().getWidth()+300){
                eliminar(false);
            }else if(p1[1]>getWorld().getHeight()+50){
                eliminar(false);
            }
        }
    }
    
    
    void eliminar(boolean animacion){
        if(animacion){
            ReboteWorld w =(ReboteWorld) getWorld();
            estoyVivo=false;
            w.vecEstrella.removeElement((Star)this);
            
            w.removeObject(this);
        }else{
            ReboteWorld w =(ReboteWorld) getWorld();
            estoyVivo=false;
            w.vecEstrella.removeElement((Star)this);
            //System.out.println("Estrella "+w.vecEstrella.size());
            
            w.removeObject(this);
        }
    }
    
}