import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Jugar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jugar extends Actor
{
    
    
    public void act() 
    {
        Menu m=(Menu)getWorld();
        if(Greenfoot.mouseMoved(this)){
            
            m.flecha.posicionar(getX()-120,getY());
            
        }
        if(Greenfoot.mouseClicked(this)){
            m.mundoJuego();
        }
    }    
}
