import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Vector;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ReboteWorld extends World
{
    Vector<Bomba> vecMeteorito = new Vector<Bomba>();//todos los meteoritos del mundo
    Vector<Bombi> vecMisil = new Vector<Bombi>();//todos los misiles del mundo
    Vector<Boom> vecExplosion = new Vector<Boom>();
    Vector<Star> vecEstrella = new Vector<Star>();
    Vector<Marco> vecMarco = new Vector<Marco>();
    Vector<Columna> vecColumna = new Vector<Columna>();

    Player player;
    Fps objFps;
    Puntos objPuntos;

    long time;
    long time0;
    long time1;
    float tpf;
    float tpt; 
    int nTicks; 
    float tPrecision;
    boolean primeraVez;
    float tiempoPorMeteorito;
    float tiempoPorEstrella;
    float tiempoPorColumnaMinimo;//minimo tiempo entre columnas(hay cierta aleatoridad)
    float contadorTiempoMeteorito;
    float contadorTiempoEstrella;
    float contadorTiempoColumna;
    float multiplicadorDelTiempo;//a cuantos segundos equivalen 1 segundo de la vida real (para camara lenta)
    boolean finJuego;

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public ReboteWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 500, 1,false); 
        primeraVez=true;
        time0=System.nanoTime();
        tPrecision=0.04f;
        tiempoPorMeteorito=0.35f;
        tiempoPorEstrella=0.1f;
        tiempoPorColumnaMinimo=3f;
        multiplicadorDelTiempo=1;
        finJuego=false;
        setPaintOrder(Fps.class,Puntos.class,Boom.class,Player.class,Bombi.class,Bomba.class,Marco.class,Columna.class);

        prepare();
    }

    public void act(){
        if(primeraVez){
            player = new Player();
            addObject(player,200,250);
            objFps = new Fps();
            addObject(objFps,100,25);
            objPuntos = new Puntos();
            addObject(objPuntos,200,25);
            objPuntos.setPrefix( " P: ");
            
            
            Marco marco1=new Marco();
            addObject(marco1,300,15);
            marco1.lugar=true;
            marco1.act();
            marco1.p1[0]=300;

            marco1=new Marco();
            addObject(marco1,900,0);
            marco1.lugar=true;
            marco1.act();
            marco1.p1[0]=670;

            //marco1.
            Marco marco2=new Marco();
            addObject(marco2,900,0);
            marco2.lugar=false;
            marco2.act();
            marco2.p1[0]=300;

            marco2=new Marco();
            addObject(marco2,900,0);
            marco2.lugar=false;
            marco2.act();
            marco2.p1[0]=670;

            primeraVez=false;
        }
        // System.out.println("n Meteoritos "+vecMeteorito.size());
        // System.out.println("n Misiles "+vecMisil.size());
        // System.out.println("--------");
        time1=System.nanoTime();
        time=time1-time0;
        time0=time1;
        tpf=(float)(time/(1000000000*multiplicadorDelTiempo));
        // System.out.println("s "+tpf);

        //System.out.println("fps "+Math.round(1/tpf));
        objFps.setValue((int)(1/tpf));
        objPuntos.setValue(player.puntuacion);
        
        contadorTiempoMeteorito=contadorTiempoMeteorito+tpf;
        contadorTiempoEstrella=contadorTiempoEstrella+tpf;
        contadorTiempoColumna=contadorTiempoColumna+tpf;
        nTicks=(int)(tpf/tPrecision);
        tpt=tPrecision;
        if (!finJuego){
            //System.out.print(contadorTiempoMeteorito);
            if(contadorTiempoMeteorito>tiempoPorMeteorito){
                contadorTiempoMeteorito=0;
                addObject(new Bomba(),900,500-Greenfoot.getRandomNumber(getHeight()));
            }
            if(contadorTiempoEstrella>tiempoPorEstrella){
                contadorTiempoEstrella=0;
                addObject(new Star(),900,500-Greenfoot.getRandomNumber(getHeight()));
            }
            if(contadorTiempoColumna>tiempoPorColumnaMinimo){
                if(true){
                    contadorTiempoColumna=0;
                    Columna columna=(Columna)new Columna();
                    addObject(columna,900,500-Greenfoot.getRandomNumber(getHeight()));
                    if(Greenfoot.getRandomNumber(2)==0){
                        columna.lugar=true;
                    }else{
                        columna.lugar=false;
                    }
                }
            }

            if(nTicks>0){
                for(int i=1;i<=nTicks;i++){
                    for(int n=0;n<vecMeteorito.size();n++){
                        vecMeteorito.get(n).toDo(tpt);
                    } 
                    player.toDo(tpt);

                    for(int n=0;n<vecMisil.size();n++){
                        vecMisil.get(n).toDo(tpt);
                    }

                    for(int n=0;n<vecExplosion.size();n++){
                        vecExplosion.get(n).toDo(tpt);
                    }
                    for(int n=0;n<vecEstrella.size();n++){
                        vecEstrella.get(n).toDo(tpt);
                    }
                    for(int n=0;n<vecMarco.size();n++){
                        vecMarco.get(n).toDo(tpt);
                    }
                    for(int n=0;n<vecColumna.size();n++){
                        vecColumna.get(n).toDo(tpt);
                    }
                }

            }
            tpt=tpf%tPrecision;
            if(tpt>0){
                for(int n=0;n<vecMeteorito.size();n++){
                    vecMeteorito.get(n).toDo(tpt);
                } 
                player.toDo(tpt);

                for(int n=0;n<vecMisil.size();n++){
                    vecMisil.get(n).toDo(tpt);
                }

                for(int n=0;n<vecExplosion.size();n++){
                    vecExplosion.get(n).toDo(tpt);
                }
                for(int n=0;n<vecEstrella.size();n++){
                    vecEstrella.get(n).toDo(tpt);
                }
                for(int n=0;n<vecMarco.size();n++){
                    vecMarco.get(n).toDo(tpt);
                }
                for(int n=0;n<vecColumna.size();n++){
                    vecColumna.get(n).toDo(tpt);
                }
            }
        }
    }

    public void finalizarJuego(){
        finJuego=true;
        for(int n=0;n<vecMisil.size();n++){
            vecMisil.get(n).eliminar(true);
        }
        for(int n=0;n<vecMeteorito.size();n++){
            vecMeteorito.get(n).eliminar(true);
        } 
        for(int n=0;n<vecExplosion.size();n++){
            vecExplosion.get(n).toDo(0.1f);
        }
        for(int n=0;n<vecMeteorito.size();n++){
            vecMeteorito.get(n).toDo(tpt);
        } 
        for(int n=0;n<vecMeteorito.size();n++){
            vecMeteorito.get(n).eliminar(true);
        } 
        Menu menu=new Menu();
        menu.puntuacionPartida=player.puntuacion;
        Greenfoot.setWorld(menu);

    }

    public void anyadirObjetoMeteorito(Bomba obj){
        vecMeteorito.addElement(obj);
    }

    public void anyadirObjetoMisil(Bombi obj){
        vecMisil.addElement(obj);
    }

    public void anyadirObjetoExplosion(Boom obj){
        vecExplosion.addElement(obj);
    }

    public void anyadirObjetoEstrella(Star obj){
        vecEstrella.addElement(obj);
    }

    public void anyadirObjetoMarco(Marco obj){
        vecMarco.addElement(obj);
    }

    public void anyadirObjetoColumna(Columna obj){
        vecColumna.addElement(obj);
    }

    public Bomba nuevoMeteorito(){
        Bomba m=new Bomba();

        addObject(m, 0,0);
        return m;
    }

    public Bombi nuevoBombi(){
        Bombi m=new Bombi();
        addObject(m, 900,0);
        return m;
    }

    public Boom nuevoExplosion(){
        Boom m=new Boom();

        addObject(m, 900,0);
        return m;
    }

    public Marco nuevoMarco(){
        Marco m=new Marco();

        addObject(m, 900,0);
        return m;
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
