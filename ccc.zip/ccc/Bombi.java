import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Vector;
import java.util.List;

public class Bombi extends Actor
{
    boolean primeraVez;
    // long time;
    // long time0;
    // long time1;
    // float tpf; //tiempo por frame
    float tpt; //tiempo por tick
    // int nTicks; //numero de ticks
    // float tPrecision;
    ReboteWorld mundo;
    List<Bomba> ObjetosColision;

    float masa;
    float gravedad;
    float cRozamiento;//cueficiente de rozamiento
    float frModulo;
    float fr[]=new float[2];//vector fuerza de rozamiento
    float ar[]=new float[2]; //vector aceleracion de rozamiento
    float reboteParedes;

    float p0[]=new float[2]; //vector posicion inicial
    float p1[]=new float[2]; //vector posicion final

    float vLimite;
    float v0[]=new float[2]; //vector posicion inicial
    float v1[]=new float[2]; //vector posicion final
    float v1Modulo; //modulo de velocidad final

    float fImpulso;
    float fnModulo; //modulo de fuerza normal
    float anModulo; //modulo de la aceleracion normal
    float dfn;//direccion de la fuerza normal en grados
    float fn[]=new float[2];//vector fuerza aceleradora
    float an[]=new float[2]; //vector aceleracion
    float angulo;//angulo de aceleracion
    float reducVChocar; //reduce la velocidad al chocar 2 bolas (del 0 al 1)
    float radio;
    float anguloRotacion;

    boolean despuesColision;
    boolean sePuedeCalcularColision;
    Vector<Bomba> vecObjColision = new Vector<Bomba>();//guarda los objetos con quien colisiona para saber cuando deja de colisionar
    float tiempoPorDisparo;
    float contadorTiempoDisparo;
    boolean estoyVivo;
    float danyo;
    public Bombi(){
        // time0=System.nanoTime();

        // tPrecision=0.0001f;
        fImpulso=50000;
        masa=0.0008f;
        cRozamiento=0.03f;
        gravedad=-1500f;
        v0[0]=0;
        v0[1]=0;
        v1[0]=500;
        v1[1]=0;
        vLimite=750f;
        frModulo=-cRozamiento*gravedad*masa;

        despuesColision=false;
        reducVChocar=800f;
        primeraVez=true;
        radio=10;
        reboteParedes=0.5f;
        anguloRotacion=0;
        contadorTiempoDisparo=0;
        tiempoPorDisparo=1f;
        estoyVivo=true;
        danyo=4f;

    }

    public void act(){
        if (primeraVez){

            ReboteWorld mundo=(ReboteWorld) getWorld();
            mundo.anyadirObjetoMisil(this);
            //System.out.println("dfn ,, "+dfn);
            calcularVectorVelocidad();
            primeraVez=false;
        }
    } 

    public void toDo(float ttt){
        // System.out.println("--------");
        // time1=System.nanoTime();
        // time=time1-time0;
        // time0=time1;
        // tpf=(float)time/1000000000;
        // System.out.println("s "+tpf);
        // System.out.println("fps "+Math.round(1/tpf));

        // nTicks=(int)(tpf/tPrecision);
        // tpt=tPrecision;
        tpt=ttt ;//tiempo de dicho instante (para los calculos)
        contadorTiempoDisparo=contadorTiempoDisparo+tpt;
        //System.out.println("s "+tpt);
        //System.out.println("tiempoo "+contadorTiempoDisparo+"  "+tiempoPorDisparo);
        //comprobarContoles();
        //comprobarRaton();
        //calcularVectorAceleracion();

        //aplicarRozamiento();
        calcularPosicion();
        if(estoyVivo){
            posicionar();
            //rotacionNave();
            comprobarColisiones(true);

        }

        // float gg[]=new float[2];
        // float ff[]=new float[2];
        // gg[0]=0;
        // gg[1]=1456;
        // ff[0]=0f;
        // ff[1]=0.1f;
        // System.out.println("Angulo  "+anguloEntre2Vectores(ff,gg));

        //consola();
        //System.out.println("v1Modulo= "+v1Modulo);
        //ReboteWorld mundo=(Mundo) getWorld();
        //mundo.setCoords((int)(p1[0]+v1[0]/7),(int)(p1[1]+v1[1]/7));
    } 

    void eliminar(boolean animacion){
        if(animacion){
            ReboteWorld w =(ReboteWorld) getWorld();
            estoyVivo=false;
            w.vecMisil.removeElement((Bombi)this);
            Boom explos=(Boom)w.nuevoExplosion();

            explos.p1[0]=p1[0];
            explos.p1[1]=p1[1];
            explos.tamanyo=40;

            w.removeObject(this);
        }else{
            ReboteWorld w =(ReboteWorld) getWorld();
            estoyVivo=false;
            w.vecMisil.removeElement((Bombi)this);
            Boom explos=(Boom)w.nuevoExplosion();

            explos.p1[0]=p1[0];
            explos.p1[1]=p1[1];
            explos.tamanyo=50;

            w.removeObject(this);
        }
    }

    private void comprobarColisiones(boolean desdeDondeSeHaLlamado){
        if(desdeDondeSeHaLlamado)sePuedeCalcularColision=true;
        if(sePuedeCalcularColision){
            if(!desdeDondeSeHaLlamado)sePuedeCalcularColision=false;
            float vv[]=new float[2];
            float AB[]=new float[2];
            float _v1[]=new float[2];//velocidad del otro objeto
            float _p1[]=new float[2];//posicion del otro objeto
            float _masa;
            float _v1Modulo;
            float ABModulo;
            float d1;
            float d2;

            float uAB[]=new float[2];//vector unitario de AB
            float uN[]=new float[2];//vector perpenducular a uAB
            float angAB1; //angulo que forman uAB y v1
            float angAB2;//angulo que forman uAB y _v1
            float angU1;//angulo que forman uN y v1
            float angU2;//angulo que forman uN y _v1
            // ObjetosColision=getObjectsInRange((int)(radio*2),Meteorito.class);
            // for(int n=0;n<ObjetosColision.size();n++){
            Bomba bola=(Bomba)getOneIntersectingObject(Bomba.class);

            if (bola==null || bola.miniMeteorito){

            }else if(false ){
                _p1=bola.p1;
                AB[0]=_p1[0]-p1[0];
                AB[1]=_p1[1]-p1[1];
                float l=(float)(((radio*2+2)*Math.sqrt(AB[0]*AB[0]+AB[1]*AB[1]))/(AB[0]*AB[0]+AB[1]*AB[1]));

                p1[0]=bola.p1[0]-AB[0]*l;
                p1[1]=bola.p1[1]-AB[1]*l;

            }else{
                // vecObjColision.add(bola);
                // despuesColision=true;
                _masa=bola.masa;
                _v1=bola.v1;
                _p1=bola.p1;
                //1
                AB[0]=_p1[0]-p1[0];
                AB[1]=_p1[1]-p1[1];
                //2
                angAB1=anguloEntre2Vectores(v1,AB);
                angAB2=anguloEntre2Vectores(_v1,AB);
                // System.out.println("angAB1  "+angAB1);
                // System.out.println("AB  "+AB[0]+" "+AB[1]);
                // System.out.println("v1  "+v1[0]+" "+v1[1]);
                // System.out.println("_v1  "+_v1[0]+" "+_v1[1]);

                //3
                v1Modulo=modulo(v1[0],v1[1]);
                _v1Modulo=modulo(_v1[0],_v1[1]);
                ABModulo=modulo(AB[0],AB[1]);
                //4
                d1=(float)Math.cos(Math.toRadians(angAB1))*v1Modulo;
                d2=(float)Math.cos(Math.toRadians(angAB2))*_v1Modulo;

                //5
                uAB[0]=AB[0]/ABModulo;
                uAB[1]=AB[1]/ABModulo;
                //6
                //7
                float dd[]=calcularVelocidadDespuesDeChoque(masa,_masa,d1,d2);
                //8
                float k=(float)((dd[0]*Math.sqrt(uAB[0]*uAB[0]+uAB[1]*uAB[1]))/(uAB[0]*uAB[0]+uAB[1]*uAB[1]));
                float l=(float)((dd[1]*Math.sqrt(uAB[0]*uAB[0]+uAB[1]*uAB[1]))/(uAB[0]*uAB[0]+uAB[1]*uAB[1]));

                float vC1[]=new float[2];
                float vC2[]=new float[2];
                vC1[0]=uAB[0]*k;
                vC1[1]=uAB[1]*k;
                vC2[0]=uAB[0]*l;
                vC2[1]=uAB[1]*l;
                //9
                uN[0]=-uAB[1];
                uN[1]=uAB[0];
                // System.out.println("uN  "+uN[0]+" "+uN[1]);
                //10
                angU1=anguloEntre2Vectores(v1,uN);
                angU2=anguloEntre2Vectores(_v1,uN);
                float h1=(float)Math.cos(Math.toRadians(angU1))*v1Modulo;
                float h2=(float)Math.cos(Math.toRadians(angU2))*_v1Modulo;
                //11
                k=(float)((h1*Math.sqrt(uN[0]*uN[0]+uN[1]*uN[1]))/(uN[0]*uN[0]+uN[1]*uN[1]));
                l=(float)((h2*Math.sqrt(uN[0]*uN[0]+uN[1]*uN[1]))/(uN[0]*uN[0]+uN[1]*uN[1]));
                // System.out.println("k l  "+k+" "+l);
                float vH1[]=new float[2];
                float vH2[]=new float[2];
                vH1[0]=uN[0]*k;
                vH1[1]=uN[1]*k; 
                vH2[0]=uN[0]*l;
                vH2[1]=uN[1]*l;
                //12
                // System.out.println("v1  "+v1[0]+" "+v1[1]);
                v1[0]=vC1[0]+vH1[0];
                v1[1]=vC1[1]+vH1[1];
                _v1[0]=vC2[0]+vH2[0];
                _v1[1]=vC2[1]+vH2[1];
                // bola.despuesColision=true;
                //bola.v1=_v1;
                if(!bola.miniMeteorito)bola.vida=bola.vida-danyo;

                //bola.vecObjColision.add((Meteorito)this);
                // System.out.println("v1 des  "+v1[0]+" "+v1[1]);
                l=(float)(((radio*2+2)*Math.sqrt(AB[0]*AB[0]+AB[1]*AB[1]))/(AB[0]*AB[0]+AB[1]*AB[1]));
                p1[0]=bola.p1[0]-AB[0]*l;
                p1[1]=bola.p1[1]-AB[1]*l;
                if(!bola.miniMeteorito)eliminar(false);

                //bola.posicionar();
                //bola.comprobarColisiones(false);
                //sePuedeCalcularColision=true;

            }
            // for(int i=0;i<vecObjColision.size();i++){
            // if(distObjs(vecObjColision.get(i),this)<=radio*2+1){

            // }else{
            // if(vecObjColision.get(i).vecObjColision.contains((Meteorito)this)){
            // eliminarElementoDeVecObjColision((Meteorito)this);
            // }

            // vecObjColision.remove(i);
            // i=i-1;
            // }
            // }
            // }

        }
    }

    void comprobarRaton(){
        if(Greenfoot.getMouseInfo().getButton()==1){
            if(contadorTiempoDisparo>tiempoPorDisparo){
                contadorTiempoDisparo=0;

            }
        }
    }

    void rotacionNave(){
        float pRaton[]=new float[2];
        boolean sePuedeRotar=true;
        try{//error significa que el raton no esta dentro del escenario
            pRaton[0]=Greenfoot.getMouseInfo().getX();
            pRaton[1]=Greenfoot.getMouseInfo().getY();

        }catch(Exception a){
            sePuedeRotar=false;
        }
        if(sePuedeRotar){

            turnTowards((int)pRaton[0],(int)pRaton[1]);
            pRaton[1]=getWorld().getHeight()-pRaton[1];//en mi sistema de cordenadas Y esta invertida
            float ejeX[]=new float[2];//vector eje x
            ejeX[0]=1;
            ejeX[1]=0;
            float AB[]=new float[2];//vector de Nave hasta Raton para calcular angulo
            AB[0]=pRaton[0]-p1[0];
            AB[1]=pRaton[1]-p1[1];
            //calcula angulo de rotacion
            if(AB[1]>0){
                anguloRotacion=anguloEntre2Vectores(ejeX,AB);
            }else{
                anguloRotacion=360-anguloEntre2Vectores(ejeX,AB);
            }

            // System.out.println("anguloRotacion   "+anguloRotacion+"  "); 
            // System.out.println("pRaton   "+pRaton[0]+"  "+pRaton[1]);
            // System.out.println("AB   "+AB[0]+"  "+AB[1]);
        }
    }

    public float distObjs(Bomba a,Bomba b){
        float xa=a.p1[0];
        float ya=a.p1[1];
        float xb=b.p1[0];
        float yb=b.p1[1];

        float d=(float)Math.sqrt(Math.pow(xb-xa,2)+Math.pow(yb-ya,2));

        return d;
    }

    public void eliminarElementoDeVecObjColision(Bomba bola){
        for(int i=0;i<vecObjColision.size();i++){
            if(vecObjColision.get(i)==bola){
                vecObjColision.remove(i);
                i=i-1;
            }
        }
    }

    public float[] calcularVelocidadDespuesDeChoque(float x,float y,float a,float b){//x=masa,y=_masa,a=d1,b=d2
        float t[]=new float[2];
        int caso=0;
        if(a>0&&b>0)caso=1;
        if(a<0&&b<0)caso=2;
        if(a<0&&b>0)caso=3;
        if(a>0&&b<0)caso=4;
        if(a==0||b==0)caso=0;
        switch(caso) {
            case 0 :
            t[0]=(a*x-a*y+2*b*y)/(x+y);
            t[1]=(2*a*x-b*x+b*y)/(x+y);
            break;
            case 1 :
            if(a>b){
                t[0]=(a*x-a*y+2*b*y)/(x+y);
                t[1]=(2*a*x-b*x+b*y)/(x+y);
            }else{
                t[0]=a;
                t[1]=b;
            }

            break; 
            case 2 :
            if(a>b){
                t[0]=(a*x-a*y+2*b*y)/(x+y);
                t[1]=(2*a*x-b*x+b*y)/(x+y);
            }else{
                t[0]=a;
                t[1]=b;
            }
            break;
            case 3 :
            t[0]=a;
            t[1]=b;
            break;
            case 4 :
            t[0]=(a*x-a*y+2*b*y)/(x+y);
            t[1]=(2*a*x-b*x+b*y)/(x+y);
            break;

            default : 
            t[0]=(a*x-a*y+2*b*y)/(x+y);
            t[1]=(2*a*x-b*x+b*y)/(x+y);
        }

        return t;
    } 

    private float anguloEntre2Vectores(float a[],float b[]){
        if(modulo(a[0],a[1])==0 || modulo(b[0],b[1])==0){
            return 0;
        }else{
            float k= (float)Math.toDegrees(Math.acos((a[0]*b[0]+a[1]*b[1])/(Math.sqrt(Math.pow(a[0],2)+Math.pow(a[1],2))*Math.sqrt(Math.pow(b[0],2)+Math.pow(b[1],2)))));
            if(Float.isNaN(k)){
                return 0;
            }else{
                return k;
            }
        }
    }

    public float[] getV1(){

        return v1;
    }

    public void setV1(float v[]){
        //v1[0]=v[0]*reducVChocar;
        //v1[1]=v[1]*reducVChocar;
        v1[0]=-v1[0]*reducVChocar;
        v1[1]=-v1[1]*reducVChocar;
        despuesColision=true;
    }

    public void aplicarRozamiento(){
        float k=1;
        float v1VU[]=new float[2]; //vector unitario de v1
        v1VU[0]=v1[0]/v1Modulo;
        v1VU[1]=v1[1]/v1Modulo;

        float rozamiento=frModulo*tpt;

        v1Modulo=v1Modulo-rozamiento;

        if(v1Modulo<0){
            v1Modulo=0;
            v1[0]=0;
            v1[1]=0;
        }else{
            k=(float)((v1Modulo*Math.sqrt(v1[0]*v1[0]+v1[1]*v1[1]))/(v1[0]*v1[0]+v1[1]*v1[1]));
            v1[0]=v1[0]*k;
            v1[1]=v1[1]*k;
        }

        //se busca un numero que al multiplicar el vector unitario dé un vector con el modulo igual a rozamiento

        //k=(float)((rozamiento*Math.sqrt(v1VU[0]*v1VU[0]+v1VU[1]*v1VU[1]))/(v1VU[0]*v1VU[0]+v1VU[1]*v1VU[1]));
        //fr[0]=v1VU[0]*k;
        //fr[1]=v1VU[1]*k;

        //v1[0]=v1[0]+fr[0];
        //v1[1]=v1[1]+fr[1];

    }

    public void consola(){
        System.out.println("anModulo "+anModulo);
        System.out.println("an "+an[0]+" "+an[1]);
        System.out.println("dfn "+dfn+" "+angulo);
        System.out.println("v1 "+v1[0]+" "+v1[1]);
        System.out.println("Fr "+frModulo+" "+fr[0]+" "+fr[1]);
        System.out.println("p1 "+p1[0]+" "+p1[1]);
        System.out.println("touchin "+isTouching(Bombi.class)+isTouching(Obs.class));

    } 

    private void posicionar(){
        setLocation((int)p1[0],getWorld().getHeight()-(int)p1[1]);
    }

    private void calcularPosicion(){
        p1[0]=p1[0]+v1[0]*tpt;
        p1[1]=p1[1]+v1[1]*tpt;
        if(p1[0]<0-50){
            eliminar(false);
        }else if(p1[1]<0-50){
            eliminar(false);
        }
        if(estoyVivo){
            if(p1[0]>getWorld().getWidth()+300){
                eliminar(false);
            }else if(p1[1]>getWorld().getHeight()+50){
                eliminar(false);
            }
        }
    }

    // private void calcularVectorVelocidad(){
    // float k=0;
    // v1[0]=v1[0]+an[0]*tpt;
    // v1[1]=v1[1]+an[1]*tpt;
    // v1Modulo=(float)Math.sqrt(v1[0]*v1[0]+v1[1]*v1[1]);
    // if(v1Modulo>vLimite){
    // //calculo por cual numero debo multiplicar el vector para que su modulo sea igual al vlimite
    // k=(float)((vLimite*Math.sqrt(v1[0]*v1[0]+v1[1]*v1[1]))/(v1[0]*v1[0]+v1[1]*v1[1]));
    // v1[0]=v1[0]*k;
    // v1[1]=v1[1]*k;
    // v1Modulo=(float)Math.sqrt(v1[0]*v1[0]+v1[1]*v1[1]);
    // }
    // //System.out.println("v1Modulo= "+v1Modulo);

    // }

    private void calcularVectorVelocidad(){
        int signoX=1;
        int signoY=1;
        angulo=1;
        //

        if (dfn>360 || dfn<-360){
            dfn=(dfn%360)*360;
        }
        if (dfn<0){
            dfn=360+dfn;
        }
        if (dfn>=0 && dfn<=90){
            signoX=1;
            signoY=1;
            angulo=dfn;
        }else if (dfn>90 && dfn<=180){
            signoX=-1;
            signoY=1;
            angulo=180-dfn;
        }else if (dfn>180 && dfn<=270){
            signoX=-1;
            signoY=-1;
            angulo=dfn-180;
        }else if (dfn>270 && dfn<=360){
            signoX=1;
            signoY=-1;
            angulo=360-dfn;
        }

        v1[0]=(float)redondear(13,(Math.cos(Math.toRadians(angulo))*vLimite*signoX));
        v1[1]=(float)redondear(13,(Math.sin(Math.toRadians(angulo))*vLimite*signoY));

    }

    private void comprobarContoles(){
        //controles w y s (Y)

        if(Greenfoot.isKeyDown("w") && !Greenfoot.isKeyDown("s")){
            fnModulo=fImpulso;
            dfn=90;
        } else if (!Greenfoot.isKeyDown("w") && Greenfoot.isKeyDown("s")){
            fnModulo=fImpulso;
            dfn=270;
        }else if (Greenfoot.isKeyDown("w") && Greenfoot.isKeyDown("s")){
            fnModulo=0;
            dfn=0;
        }else{
            fnModulo=0;
        }

        //controles a y d (X)
        if(Greenfoot.isKeyDown("a") && !Greenfoot.isKeyDown("d")){
            fnModulo=fImpulso;
            dfn=180;
        } else if (!Greenfoot.isKeyDown("a") && Greenfoot.isKeyDown("d")){
            fnModulo=fImpulso;
            dfn=0;
        }else if (Greenfoot.isKeyDown("a") && Greenfoot.isKeyDown("d")){
            fnModulo=0;
            dfn=0;
        }else{

        }

        //Ambos a la vez
        if(Greenfoot.isKeyDown("w") && Greenfoot.isKeyDown("d")){
            fnModulo=fImpulso;
            dfn=45;
        } else if (Greenfoot.isKeyDown("w") && Greenfoot.isKeyDown("a")){
            fnModulo=fImpulso;
            dfn=135;
        }else if (Greenfoot.isKeyDown("s") && Greenfoot.isKeyDown("a")){
            fnModulo=fImpulso;
            dfn=225;
        }else if (Greenfoot.isKeyDown("s") && Greenfoot.isKeyDown("d")){
            fnModulo=fImpulso;
            dfn=315;
        }else{

        }
        if (Greenfoot.isKeyDown("space")){
            v1[0]=0;
            v1[1]=0;
        }

    }

    private float modulo(float a,float b){
        return (float)Math.sqrt(a*a+b*b);
    }

    private double redondear(int a,double n){
        return Math.round(n*Math.pow(10,a))/Math.pow(10,a);

    }

    private float mrua(float x0,float v,float g,float t) {
        return (float)(x0+v*t+0.5*g*t*t);
    }
}
