import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Flecha here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Flecha extends Actor
{
    float animacion;
    float mAnimation;//hace que la animacion sea mas agresiva 
    float posx;
    float posy;
    boolean primeraVez;
    public Flecha(){
        primeraVez=true;
        animacion=0;
        mAnimation=1;
        posx=0;
        posy=0;
    }

    public void act() 
    {

        if(primeraVez){
            posx=getX();
            posy=getY();
            primeraVez=false;
        }
        setRotation((int)(Math.sin((animacion))*10));
        setLocation((int)(posx+Math.sin((animacion))*3*mAnimation),(int)(posy+Math.sin((animacion-90))*6*mAnimation));
        animacion=animacion+0.05f;
    }

    public void posicionar(int x,int y){
        setLocation(x,y);
        posx=x;
        posy=y;
    }
}
