import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Dibuja una barra de progreso 
 * 
 * @author (Jaime Brull)
 * @version (a version number or a date)
 */
//import java.awt.Color;

public class BarraProgreso extends Actor
{
    private int valorMaximo=100;
    private int valorMinimo=0;

    private int valor=100;
    private int valorAnterior=0;
    private int grosor=1;

    private Color colorFondo= new Color(120,100,120);
    private Color colorRectangulo= new Color(253,145,145);
    private Color colorValor=new Color(138,195,161);
    private Color colorTexto=new Color(255,255,255);
    private String texto="Energia";

    public int getValor(){
        return valor;
    }

    public void setValor(int valor){
        this.valor=valor;
        dibujar();
    }

    public void setValorMaximo(int valor){
        this.valorMaximo=valor;
        if (getWorld()!=null)  dibujar();
    }

    public void setTexto(String texto){
        this.texto=texto;
        dibujar();
    }

    public BarraProgreso(){
        valorAnterior=valor;
        dibujar();
    }

    private void dibujar(){
        GreenfootImage img= new GreenfootImage(100,20);
        img.setColor(colorFondo);
        img.fill();
        img.setColor(colorRectangulo);
        img.drawRect(0, 0, img.getWidth()-1, img.getHeight()-1);
        img.setColor(colorValor);
        int ancho=(int)valor*img.getWidth()/valorMaximo;
        img.fillRect(grosor, grosor, ancho-grosor-1, img.getHeight()-1-grosor);
        img.setColor(colorTexto);
        img.drawString(texto + String.valueOf(valor), grosor*2, img.getHeight()-5);
        setImage(img);        
    }

    /**
     * Act - do whatever the Energia wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (valorAnterior<valor){
            for(int i=valor;i<=valorAnterior;i++){
                valor=valor+1;
                dibujar();
            }
            valorAnterior=valor;
        }
    }    

    
    
    
    
}
