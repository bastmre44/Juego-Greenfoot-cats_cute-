import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends World
{

    int puntuacionPartida;
    Flecha flecha;
    PuntuacionMenu puntuacionMenu;
    boolean primeraVez;
    public Menu()
    {    

        super(900, 540, 1,false); 
        addObject(new Jugar(),400, 200);
        addObject(new Salir(),400, 300);

        flecha=new Flecha();
        addObject(flecha,-100, -100);
        puntuacionPartida=-1;
        primeraVez=true;
        Greenfoot.setSpeed(57);

        prepare();
    }

    public void act(){
        if(primeraVez){

            if(puntuacionPartida!=-1){
                puntuacionMenu=new PuntuacionMenu();
                addObject(puntuacionMenu,getWidth()/2,100);
                puntuacionMenu.setPrefix("Puntuacion: ");
                puntuacionMenu.setValue(puntuacionPartida);
            }
            primeraVez=false;

        }
    }

    public void mundoJuego(){
        Greenfoot.setWorld(new ReboteWorld());
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
